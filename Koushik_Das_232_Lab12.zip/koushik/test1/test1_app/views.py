from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def reg(request):
    # return HttpResponse("Hello",request)
    return render(request,'reg.html')

def login(request):
    # return HttpResponse("Hello",request)
    return render(request,'login.html')