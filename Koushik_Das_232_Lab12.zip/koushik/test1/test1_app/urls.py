from django.urls import path
from test1_app import views

urlpatterns = [
    path('reg',views.reg),
    path('login',views.login)
]